'''
    onedrive XBMC Plugin
    Copyright (C) 2013-2014 ddurdle

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import xbmc, xbmcgui, xbmcplugin, xbmcaddon


import sys
import urllib
import cgi
import re
import xbmcvfs


# global variables
PLUGIN_NAME = 'onedrive'



#helper methods
def log(msg, err=False):
    if err:
        xbmc.log(addon.getAddonInfo('name') + ': ' + msg, xbmc.LOGERROR)
    else:
        xbmc.log(addon.getAddonInfo('name') + ': ' + msg, xbmc.LOGDEBUG)

def parse_query(query):
    queries = cgi.parse_qs(query)
    q = {}
    for key, value in queries.items():
        q[key] = value[0]
    q['mode'] = q.get('mode', 'main')
    return q

def addMediaFile(service, package):

    listitem = xbmcgui.ListItem(package.file.title, iconImage=package.file.thumbnail,
                                thumbnailImage=package.file.thumbnail)

    if package.file.type == package.file.AUDIO:
        infolabels = decode_dict({ 'title' : package.file.title })
        listitem.setInfo('Music', infolabels)
        playbackURL = '?mode=audio'
    elif package.file.type == package.file.VIDEO:
        infolabels = decode_dict({ 'title' : package.file.title , 'plot' : package.file.plot })
        listitem.setInfo('Video', infolabels)
        playbackURL = '?mode=video'
    elif package.file.type == package.file.PICTURE:
        infolabels = decode_dict({ 'title' : package.file.displayTitle() , 'plot' : package.file.plot })
        listitem.setInfo('Pictures', infolabels)
        playbackURL = '?mode=photo'
    else:
        infolabels = decode_dict({ 'title' : package.file.title , 'plot' : package.file.plot })
        listitem.setInfo('Video', infolabels)
        playbackURL = '?mode=video'

    listitem.setProperty('IsPlayable', 'true')
    listitem.setProperty('fanart_image', package.file.fanart)
    cm=[]

    try:
        url = package.getMediaURL()
        cleanURL = re.sub('---', '', url)
        cleanURL = re.sub('&', '---', cleanURL)
    except:
        cleanURL = ''

#    url = PLUGIN_URL+'?mode=streamurl&instance='+service.instanceName+'&title='+package.file.title+'&url='+cleanURL
    url = PLUGIN_URL+playbackURL+'&instance='+service.instanceName+'&title='+package.file.title+'&url='+cleanURL+'&filename='+package.file.id+'&folder='+package.folder.id
    #generate STRM
    cm.append(( addon.getLocalizedString(30042), 'XBMC.RunPlugin('+PLUGIN_URL+'?mode=buildstrm&username='+str(service.authorization.username)+'&title='+package.file.title+'&filename='+package.file.id+')', ))

#    cm.append(( addon.getLocalizedString(30042), 'XBMC.RunPlugin('+PLUGIN_URL+'?mode=buildstrm&title='+package.file.title+'&filename='+package.file.id+')', ))
#    cm.append(( addon.getLocalizedString(30042), 'XBMC.RunPlugin('+PLUGIN_URL+'?mode=buildstrm&title='+package.file.title+'&streamurl='+cleanURL+')', ))
#    cm.append(( addon.getLocalizedString(30046), 'XBMC.PlayMedia('+playbackURL+'&title='+ package.file.title + '&directory='+ package.folder.id + '&filename='+ package.file.id +'&playback=0)', ))
#    cm.append(( addon.getLocalizedString(30047), 'XBMC.PlayMedia('+playbackURL+'&title='+ package.file.title + '&directory='+ package.folder.id + '&filename='+ package.file.id +'&playback=1)', ))
#    cm.append(( addon.getLocalizedString(30048), 'XBMC.PlayMedia('+playbackURL+'&title='+ package.file.title + '&directory='+ package.folder.id + '&filename='+ package.file.id +'&playback=2)', ))
    #cm.append(( addon.getLocalizedString(30032), 'XBMC.RunPlugin('+PLUGIN_URL+'?mode=download&title='+package.file.title+'&filename='+package.file.id+')', ))

#    listitem.addContextMenuItems( commands )
    if cm:
        listitem.addContextMenuItems(cm, False)
    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem,
                                isFolder=False, totalItems=0)

    return url

def addDirectory(service, folder):
    listitem = xbmcgui.ListItem(decode(folder.title), iconImage='', thumbnailImage='')
    fanart = addon.getAddonInfo('path') + '/fanart.jpg'

    if folder.id != '':
        cm=[]
        cm.append(( addon.getLocalizedString(30042), 'XBMC.RunPlugin('+PLUGIN_URL+'?mode=buildstrm&title='+folder.title+'&username='+str(service.authorization.username)+'&folderID='+str(folder.id)+')', ))
        listitem.addContextMenuItems(cm, False)
    listitem.setProperty('fanart_image', fanart)
    xbmcplugin.addDirectoryItem(plugin_handle, service.getDirectoryCall(folder), listitem,
                                isFolder=True, totalItems=0)

def addMenu(url,title):
    listitem = xbmcgui.ListItem(decode(title), iconImage='', thumbnailImage='')
    fanart = addon.getAddonInfo('path') + '/fanart.jpg'

    listitem.setProperty('fanart_image', fanart)
    xbmcplugin.addDirectoryItem(plugin_handle, url, listitem,
                                isFolder=True, totalItems=0)


#http://stackoverflow.com/questions/1208916/decoding-html-entities-with-python/1208931#1208931
def _callback(matches):
    id = matches.group(1)
    try:
        return unichr(int(id))
    except:
        return id

def decode(data):
    return re.sub("&#(\d+)(;|(?=\s))", _callback, data).strip()

def decode_dict(data):
    for k, v in data.items():
        if type(v) is str or type(v) is unicode:
            data[k] = decode(v)
    return data


def numberOfAccounts(accountType):

    count = 1
    max_count = int(addon.getSetting(accountType+'_numaccounts'))
    actualCount = 0
    while True:
        try:
            if addon.getSetting(accountType+str(count)+'_username') != '':
                actualCount = actualCount + 1
        except:
            break
        if count == max_count:
            break
        count = count + 1
    return actualCount


#global variables
PLUGIN_URL = sys.argv[0]
plugin_handle = int(sys.argv[1])
plugin_queries = parse_query(sys.argv[2][1:])

addon = xbmcaddon.Addon(id='plugin.video.onedrive-testing')

addon_dir = xbmc.translatePath( addon.getAddonInfo('path') )

#import os
#sys.path.append(os.path.join( addon_dir, 'resources', 'lib' ) )

#import onedrive
#import cloudservice
#import folder
#import file
#import package
#import mediaurl
#import authorization


from resources.lib import onedrive
#from resources.lib import gPlayer
#from resources.lib import tvWindow
from resources.lib import cloudservice
from resources.lib import folder
from resources.lib import file
from resources.lib import package
from resources.lib import mediaurl



#debugging
try:

    remote_debugger = addon.getSetting('remote_debugger')
    remote_debugger_host = addon.getSetting('remote_debugger_host')

    # append pydev remote debugger
    if remote_debugger == 'true':
        # Make pydev debugger works for auto reload.
        # Note pydevd module need to be copied in XBMC\system\python\Lib\pysrc
        import pysrc.pydevd as pydevd
        # stdoutToServer and stderrToServer redirect stdout and stderr to eclipse console
        pydevd.settrace(remote_debugger_host, stdoutToServer=True, stderrToServer=True)
except ImportError:
    log(addon.getLocalizedString(30016), True)
    sys.exit(1)
except :
    pass


# retrieve settings
user_agent = addon.getSetting('user_agent')


mode = plugin_queries['mode']

# make mode case-insensitive
mode = mode.lower()


log('plugin url: ' + PLUGIN_URL)
log('plugin queries: ' + str(plugin_queries))
log('plugin handle: ' + str(plugin_handle))


instanceName = ''
try:
    instanceName = (plugin_queries['instance']).lower()
except:
    pass


# sorting options
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_SIZE)


if mode == 'main':
    addMenu(PLUGIN_URL+'?mode=options&instance='+instanceName,'<<'+addon.getLocalizedString(30043)+'>>')

if mode != 'main' and instanceName == '':
    instanceName = 'onedrive1'


#* utilities *
#clear the authorization token(s) from the identified instanceName or all instances
if mode == 'clearauth':

    if instanceName != '':

        try:
            # onedrive specific ***
            addon.setSetting(instanceName + '_auth_writely', '')
            addon.setSetting(instanceName + '_auth_wise', '')
            # ***
            xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30023))
        except:
            #error: instance doesn't exist
            pass

    # clear all accounts
    else:
        count = 1
        max_count = int(addon.getSetting(PLUGIN_NAME+'_numaccounts'))
        while True:
            instanceName = PLUGIN_NAME+str(count)
            try:
                # onedrive specific ***
                addon.setSetting(instanceName + '_auth_writely', '')
                addon.setSetting(instanceName + '_auth_wise', '')
                # ***
            except:
                break
            if count == max_count:
                break
            count = count + 1
        xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30023))
    xbmcplugin.endOfDirectory(plugin_handle)


#create strm files
elif mode == 'buildstrm':
    import os


    try:
        path = addon.getSetting('strm_path')
    except:
        path = xbmcgui.Dialog().browse(0,addon.getLocalizedString(30026), 'files','',False,False,'')
        addon.setSetting('strm_path', path)

    if path == '':
        path = xbmcgui.Dialog().browse(0,addon.getLocalizedString(30026), 'files','',False,False,'')
        addon.setSetting('strm_path', path)

    if path != '':
        returnPrompt = xbmcgui.Dialog().yesno(addon.getLocalizedString(30000), addon.getLocalizedString(30027) + '\n'+path +  '?')


    if path != '' and returnPrompt:

        try:
            url = plugin_queries['url']
            title = plugin_queries['title']
            url = re.sub('---', '&', url)
        except:
            url=''

        if url != '':

                filename = path + '/' + title+'.strm'
                strmFile = xbmcvfs.File(filename, "w")

                strmFile.write(url+'\n')
                strmFile.close()
        else:

            try:
                folderID = plugin_queries['folderID']
                title = plugin_queries['title']
            except:
                folderID = ''

            try:
                filename = plugin_queries['filename']
                title = plugin_queries['title']
            except:
                filename = ''


            try:
                    invokedUsername = plugin_queries['username']
            except:
                    invokedUsername = ''


            if folderID != '':

                count = 1
                max_count = int(addon.getSetting(PLUGIN_NAME+'_numaccounts'))
                loop = True
                while loop:
                    instanceName = PLUGIN_NAME+str(count)
                    try:
                        username = addon.getSetting(instanceName+'_username')
                        if username == invokedUsername:

                            #let's log in
                            service = onedrive.onedrive(PLUGIN_URL,addon,instanceName, user_agent)
                            loop = False
                    except:
                        break

                    if count == max_count:
                        break
                    count = count + 1

                service.buildSTRM(path + '/'+title,folderID)


            elif filename != '':
                            url = PLUGIN_URL+'?mode=video&title='+title+'&filename='+filename + '&username='+invokedUsername
                            filename = path + '/' + title+'.strm'
                            strmFile = xbmcvfs.File(filename, "w")

                            strmFile.write(url+'\n')
                            strmFile.close()

            else:

                count = 1
                max_count = int(addon.getSetting(PLUGIN_NAME+'_numaccounts'))
                while True:
                    instanceName = PLUGIN_NAME+str(count)
                    try:
                        username = addon.getSetting(instanceName+'_username')
                    except:
                        username = ''

                    if username != '':
                        service = onedrive.onedrive(PLUGIN_URL,addon,instanceName, user_agent)
                        service.buildSTRM(path + '/'+username)

                    if count == max_count:
                        break
                    count = count + 1


        xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30028))
    xbmcplugin.endOfDirectory(plugin_handle)


if mode == 'options' or mode == 'buildstrm' or mode == 'clearauth':
    addMenu(PLUGIN_URL+'?mode=clearauth','<<'+addon.getLocalizedString(30018)+'>>')
    addMenu(PLUGIN_URL+'?mode=buildstrm','<<'+addon.getLocalizedString(30025)+'>>')
    addMenu(PLUGIN_URL+'?mode=folder_enc&instance='+instanceName,'<<encryption>>')


numberOfAccounts = numberOfAccounts(PLUGIN_NAME)

try:
    contextType = plugin_queries['content_type']
except:
    contextType = 'video'

try:
    invokedUsername = plugin_queries['username']
except:
    invokedUsername = ''

# show list of services
if numberOfAccounts > 1 and instanceName == '' and invokedUsername == '':
    mode = ''
    count = 1
    max_count = int(addon.getSetting(PLUGIN_NAME+'_numaccounts'))
    while True:
        instanceName = PLUGIN_NAME+str(count)
        try:
            username = addon.getSetting(instanceName+'_username')
            if username != '':
                addMenu(PLUGIN_URL+'?mode=main&instance='+instanceName,username)
        except:
            break
        if count == max_count:
            break
        count = count + 1

else:
    # show index of accounts
    if instanceName == ''  and invokedUsername == '' and numberOfAccounts == 1:

        count = 1
        loop = True
        while loop:
            instanceName = PLUGIN_NAME+str(count)
            try:
                username = addon.getSetting(instanceName+'_username')
                if username != '':

                    #let's log in
                    service = onedrive.onedrive(PLUGIN_URL,addon,instanceName, user_agent)
                    loop = False
            except:
                break

            if count == numberOfAccounts:
                break
            count = count + 1

    # no accounts defined
    elif numberOfAccounts == 0:

        #legacy account conversion
        try:
            username = addon.getSetting('username')

            if username != '':
                addon.setSetting(PLUGIN_NAME+'1_username', username)
                addon.setSetting(PLUGIN_NAME+'1_password', addon.getSetting('password'))
                addon.setSetting(PLUGIN_NAME+'1_auth_writely', addon.getSetting('auth_writely'))
                addon.setSetting(PLUGIN_NAME+'1_auth_wise', addon.getSetting('auth_wise'))
                addon.setSetting('username', '')
                addon.setSetting('password', '')
                addon.setSetting('auth_writely', '')
                addon.setSetting('auth_wise', '')
            else:
                xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30015))
                log(addon.getLocalizedString(30015), True)
                xbmcplugin.endOfDirectory(plugin_handle)
        except :
            xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30015))
            log(addon.getLocalizedString(30015), True)
            xbmcplugin.endOfDirectory(plugin_handle)

        #let's log in
        service = onedrive.onedrive(PLUGIN_URL,addon,instanceName, user_agent)


    # show entries of a single account (such as folder)
    elif instanceName != '':

        service = onedrive.onedrive(PLUGIN_URL,addon,instanceName, user_agent)


    elif invokedUsername != '':

        count = 1
        max_count = int(addon.getSetting(PLUGIN_NAME+'_numaccounts'))
        loop = True
        while loop:
            instanceName = PLUGIN_NAME+str(count)
            try:
                username = addon.getSetting(instanceName+'_username')
                if username == invokedUsername:

                    #let's log in
                    service = onedrive.onedrive(PLUGIN_URL,addon,instanceName, user_agent)
                    loop = False
            except:
                break

            if count == max_count:
                break
            count = count + 1


#if mode == 'main':
#    addMenu(PLUGIN_URL+'?mode=options','<< '+addon.getLocalizedString(30043)+' >>')


#dump a list of videos available to play
if mode == 'main' or mode == 'folder' or mode == 'index':

    folderName=''
    if (mode == 'folder'):
        folderName = plugin_queries['directory']
    else:
        pass

    try:
        contextType = plugin_queries['content_type']
    except:
        contextType = 0

    if mode == 'main':
        addMenu(PLUGIN_URL+'?mode=search&instance='+instanceName+'&content_type='+str(contextType),'['+addon.getLocalizedString(30111)+']')

    try:
        service
    except NameError:
        xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30051), addon.getLocalizedString(30052))
        log(addon.getLocalizedString(30050)+ 'oc-login', True)
        xbmcplugin.endOfDirectory(plugin_handle)


    mediaItems = service.getMediaList(folderName,0)

    if mediaItems:
        for item in mediaItems:

            if item.file is None:
                addDirectory(service, item.folder)
            else:
                addMediaFile(service, item)

    service.updateAuthorization(addon)


#dump a list of videos available to play
elif mode == 'folder_enc' or mode == 'index_enc':

    folderName=''
    if (mode == 'folder'):
        folderName = plugin_queries['directory']
    else:
        pass

    pathSource = ''
    try:
        pathSource = addon.getSetting('encfs_source')
    except:
        pass

    pathTarget = ''
    try:
        pathTarget = addon.getSetting('encfs_target')
    except:
        pass


    try:
        service
    except NameError:
        xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30051), addon.getLocalizedString(30052))
        log(addon.getLocalizedString(30050)+ 'oc-login', True)
        xbmcplugin.endOfDirectory(plugin_handle)

    mediaItems = service.getMediaList(folderName,0)

    import xbmcvfs

    if mediaItems:
        for item in mediaItems:

            if item.file is None:
#                addDirectory(service, item.folder)
                xbmcvfs.mkdir(pathSource + '/'+item.folder.title)
                print xbmcvfs.Stat(pathSource + '/'+item.folder.title).st_ino()
            else:
                addMediaFile(service, item)

    dirs, files = xbmcvfs.listdir(pathTarget + '/')

    for dir in dirs:
        print xbmcvfs.Stat(pathTarget + '/'+dir).st_ino()


    service.updateAuthorization(addon)


#play a video given its exact-title
elif mode == 'video' or mode == 'search' or mode == 'audio':

    try:
        filename = plugin_queries['filename']
    except:
        filename = ''

    try:
        url = plugin_queries['url']
    except:
        url = ''

    try:
        title = plugin_queries['title']
    except:
        title = ''

    try:
        service
    except NameError:
        xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30051), addon.getLocalizedString(30052))
        log(addon.getLocalizedString(30050)+ 'oc-login', True)
        xbmcplugin.endOfDirectory(plugin_handle)

    try:
        contextType = plugin_queries['content_type']
    except:
        contextType = ''

    playbackMedia = True

    if mode == 'search' or (url == '' and filename == ''):

        if title == '':

            try:
                dialog = xbmcgui.Dialog()
                title = dialog.input(addon.getLocalizedString(30110), type=xbmcgui.INPUT_ALPHANUM)
            except:
                xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30100))
                title = 'test'

        title = re.sub(' ', '+', title)
        mediaItems = service.getMediaList(title=title)
        playbackMedia = False

        options = []
        urls = []

        if mediaItems:
            for item in mediaItems:
                if item.file is None:
                    addDirectory(service, item.folder)
                else:
                    options.append(item.file.title)
                    urls.append(addMediaFile(service, item))

        if mode != 'search':
            url = urls[0]

            item = xbmcgui.ListItem(path=url)
            item.setInfo( type="Video", infoLabels={ "Title": options[0] , "Plot" : options[0] } )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

        elif contextType == '':

            ret = xbmcgui.Dialog().select(addon.getLocalizedString(30112), options)
            url = urls[ret]

            item = xbmcgui.ListItem(path=url)
            item.setInfo( type="Video", infoLabels={ "Title": options[ret] , "Plot" : options[ret] } )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)



    if playbackMedia:
        mediaFile = file.file(filename, title, '', 0, '','')
        mediaFolder = folder.folder('','')
        media = package.package(mediaFile,mediaFolder)
        cleanURL = re.sub('---', '&', url)

        media.setMediaURL(mediaurl.mediaurl(cleanURL,'','',''))
        url = service.getPlaybackCall(media)

        item = xbmcgui.ListItem(path=url)
        item.setInfo( type="Video", infoLabels={ "Title": title , "Plot" : title } )
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

elif mode == 'photo':

    url = ''
    try:
      url = plugin_queries['url']
    except:
      pass

    title = ''
    try:
      title = plugin_queries['title']
    except:
      pass

    folder = ''
    try:
      folder = plugin_queries['folder']
    except:
      pass


    path = ''
    try:
        path = addon.getSetting('photo_folder')
    except:
        pass

    import os.path

    if not os.path.exists(path):
        path = ''

    while path == '':
        path = xbmcgui.Dialog().browse(0,addon.getLocalizedString(30038), 'files','',False,False,'')
        if not os.path.exists(path):
            path = ''
        else:
            addon.setSetting('photo_folder', path)


    try:
        service
    except NameError:
        xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30051), addon.getLocalizedString(30052))
        log(addon.getLocalizedString(30050)+ 'oc-login', True)
        xbmcplugin.endOfDirectory(plugin_handle)

    cleanURL = re.sub('---', '&', url)

    import xbmcvfs
    xbmcvfs.mkdir(path + '/'+folder)
#    xbmcvfs.mkdir(path + '/'+folder + '/dir_'+title)
    try:
        xbmcvfs.rmdir(path + '/'+folder+'/'+title)
    except:
        pass

    service.downloadPicture(cleanURL, path + '/'+folder + '/'+title)
#    item.setProperty('IsPlayable', 'true')

#    xbmc.executebuiltin("XBMC.SlideShow("+path + '/'+folder+"/)")
    xbmc.executebuiltin("XBMC.ShowPicture("+path + '/'+folder + '/'+title+")")



#play a video given its exact-title
elif mode == 'streamurl':

    url = plugin_queries['url']

    try:
        title = plugin_queries['title']
    except:
        title = ''

    try:
        service
    except NameError:
        xbmcgui.Dialog().ok(addon.getLocalizedString(30000), addon.getLocalizedString(30051), addon.getLocalizedString(30052))
        log(addon.getLocalizedString(30050)+ 'oc-login', True)
        xbmcplugin.endOfDirectory(plugin_handle)


    mediaFile = file.file('', '', '', 0, '','')
    mediaFolder = folder.folder('','')
    media = package.package(mediaFile,mediaFolder)
    cleanURL = re.sub('---', '&', url)

    media.setMediaURL(mediaurl.mediaurl(cleanURL,'','',''))
    url = service.getPlaybackCall(media)

    item = xbmcgui.ListItem(path=url)
    item.setInfo( type="Video", infoLabels={ "Title": title , "Plot" : title } )
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)



xbmcplugin.endOfDirectory(plugin_handle)

