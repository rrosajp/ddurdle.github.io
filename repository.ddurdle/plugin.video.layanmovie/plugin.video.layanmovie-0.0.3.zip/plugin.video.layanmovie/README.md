XBMC-layanmovie
===============

A XBMC video addon to playback content of layanmovies website.

This video addon requires the XBMC-gdrive plugin 0.2.7 or later video addon (since all content on the site is google drive videos)

Supports [Tested on]:
All XBMC 12 and 12.2 including Linux, Windows, OS X, Android, Pivos, iOS (including ATV2)


Getting Started:
1) download the .zip file
2) transfer the .zip file to XBMC
3) in Video Add-on, select Install from .zip


FAQ:


Current Version:
v0.0.1
- first public release


